/**
 * @internal
 */
export declare const packageVersion = "23.8.0";
//# sourceMappingURL=version.d.ts.map