/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
export * from './index-browser.js';
export * from './node/node.js';
//# sourceMappingURL=index.d.ts.map