export * from 'mitt';
export { default as default } from 'mitt';
