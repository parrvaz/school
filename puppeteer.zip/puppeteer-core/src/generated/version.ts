/**
 * @internal
 */
export const packageVersion = '23.8.0';
