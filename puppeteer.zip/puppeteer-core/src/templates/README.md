# Templated Artifacts

These files are generated as TypeScript files in the `src/generated` folder.
